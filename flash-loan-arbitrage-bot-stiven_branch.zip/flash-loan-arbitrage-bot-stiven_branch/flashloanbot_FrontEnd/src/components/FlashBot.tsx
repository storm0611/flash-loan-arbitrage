const FlashBot = () => {
    return (
      <div className="page">
        FlashBot
      </div>
    );
  }
  
  export default FlashBot;