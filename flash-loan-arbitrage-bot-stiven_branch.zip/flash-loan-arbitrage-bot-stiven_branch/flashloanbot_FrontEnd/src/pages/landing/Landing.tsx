const Landing = () => {
  return (
    <div className="page">
      Landing Page
    </div>
  );
}

export default Landing;