const News = () => {
  return (
    <div className="page">
      News Page
    </div>
  );
}

export default News;