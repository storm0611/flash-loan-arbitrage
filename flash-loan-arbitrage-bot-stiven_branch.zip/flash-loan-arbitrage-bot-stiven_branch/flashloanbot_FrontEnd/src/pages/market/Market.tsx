const Market = () => {
  return (
    <div className="page">
      Market Page
    </div>
  );
}

export default Market;