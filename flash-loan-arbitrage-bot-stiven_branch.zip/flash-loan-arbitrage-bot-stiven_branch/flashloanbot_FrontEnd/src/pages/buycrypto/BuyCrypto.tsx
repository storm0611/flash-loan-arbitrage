const BuyCrypto = () => {
  return (
    <div className="page">
      BuyCrypto Page
    </div>
  );
}

export default BuyCrypto;